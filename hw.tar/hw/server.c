#define _POSIX_C_SOURCE 200112L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>

#define SSIZE 32
#define BACKLOG 5
#define FAIL perror("Error"); return EXIT_FAILURE;

int running = 1;

struct node{
    char* key;
    char* value;
    struct node* next;
};
typedef struct LL{
    struct node* head;
    unsigned num;       //number of nodes in list
}LL;
struct args{
    struct sockaddr_storage addr;
    socklen_t addr_len;
    int fd;
    LL* list;
};

void handler(int signal) {
    running = 0;
}

int n_init(struct node* node) {
    node->key = malloc(SSIZE); 
    if(!node->key) {FAIL}       //if fail, report error/exit
    node->value = malloc(SSIZE); 
    if(!node->value) {FAIL}     //if fail, report error/exit
    node->next = NULL;
    return 0;
}
int initibuf(char *buf,int len){
	for(int i=0;i<len;i++){
		buf[i]='\0';
	}
	return 0;
}
int n_destroy(struct node* head) {
    struct node* temp;
    while(head) {
        free(head->key);
        free(head->value);
        temp = head;
        head = head->next;
        free(temp);
    }
    return 0;
}
int n_contains(struct node* head, char* str) {  //0: does not contain
    int contain = 0;                            //1: contains
    struct node* curr = head;
    while(curr) {
        if(strcmp(curr->key, str)==0) {
            contain = 1;
            break;
        }
        curr = curr->next;
    }
    return contain;
}
struct node* n_insert(struct node* head, struct node* node) {
    struct node* curr = head;
    struct node* prev = NULL;
    while(curr) {
        if (strcmp(node->key, curr->key)<0) break;
        prev = curr;
        curr = curr->next;
    }
    if(!prev) {
        node->next = head;
        head = node;
    } else {
        prev->next = node;
        node->next = curr;
    }
    return head;
}
int l_init(LL* list) {
    list->head = NULL;
    list->num = 0;
    return 0;
}
void n_print(struct node* head) {
    struct node* curr = head;
    while(curr) {
        printf("key: %s\tvalue: %s\n", curr->key, curr->value);
        curr = curr->next;
    }
    putchar('\n');
}

int get(LL* list, char* key, char** value) {    //if key is set, 
                                                //return value. <-(put in pointer(?))
    if(!n_contains(list->head, key)) {          //if not return KNF
        return -1;
    }
    struct node* curr = list->head;
    while(curr) {
        if(strcmp(curr->key, key)==0) {
            strcpy(*value, curr->value);
            break;
        }
        curr = curr->next;
    }                                            
    return 0;
}
int set(LL* list, char* key, char* value) {     //if key doesn't exist, 
                                                //create new node + set key              
    if(n_contains(list->head, key)) {           //if key exist, change value of key (?)
        struct node* curr = list->head;
        while(curr) {
            if(strcmp(curr->key, key)==0) {
                strcpy(curr->value, value);
                break;
            }
            curr = curr->next;
        }
        return 0;
    }

    struct node* node = malloc(sizeof(struct node)); //if fail, report error/exit
    if(!node) { 
        perror("Error");
        abort();
    }
    n_init(node);
    strcpy(node->key, key);
    strcpy(node->value, value);

    if(!list->num) { 
        list->head = node;
        list->num++;
        return 0;
    }
    
    list->head = n_insert(list->head, node);
    list->num++;                                          
    return 0;
}
int del(LL* list, char* key, char** value) {    //if key doesn't exist, return KNF
                                                //if key exist, remove node
    if(!n_contains(list->head, key)) {
        return -1;
    }

    struct node* curr = list->head;
    struct node* prev = NULL;
    while(curr) {
        if(strcmp(curr->key, key)==0) break;
        prev = curr;
        curr = curr->next;
    }

    if(!prev) { //remove head
        strcpy(*value, list->head->value);
        list->head = list->head->next;    
    } else {
        strcpy(*value, curr->value);
        prev->next = curr->next;
    }
    free(curr->key);
    free(curr->value);
    free(curr); //D:<
    list->num--;
    return 0;
}

int errlen(int len, int size, FILE* f) {
    if(len!=size) {
        fprintf(f, "ERR\nLEN\n");
        fflush(f);
        printf("Bad length.\nClosing connection.\n");
        return -1;
    }
    return 0;
}

char* meltstring(char *string1, int string1_len, char *string2, int string2_len){
	for(int i=0;i+string1_len<50&&i<string2_len;i++){
		string1[i+string1_len]=string2[i];
	}
	return string1;
}
void* key(void* arg) { 

    char host[100], port[10];
    struct args* a = arg;
    int nread,  buflen, err;
	nread=0;
    

    FILE* fout = fdopen(a->fd, "w");
    if(!fout) {perror("Error"); return NULL;}

	char* buffer = malloc(sizeof(char)*32);
    if(!buffer) {perror("Error"); return NULL;}
	char* buffer1 = malloc(sizeof(char)*32);
    if(!buffer1) {perror("Error"); return NULL;}

	char* value;
	initibuf(buffer,32);
	initibuf(buffer1,32);

    err = getnameinfo((struct sockaddr*)&a->addr, a->addr_len, host, 100, port, 10, NI_NUMERICSERV);
    if(err!=0) {
        fprintf(stderr, "getnameinfo: %s", gai_strerror(err));
        fclose(fout);
        return NULL;
    }
    //check error

    for(nread=read(a->fd,buffer,4);nread!=0;nread=read(a->fd,buffer,4)){
    
	buflen=nread;
	value = malloc(SSIZE);
    if(!value) {perror("Error"); return NULL;}

    while(buflen<4)
	{
		nread=read(a->fd,buffer1,4-buflen);
		meltstring(buffer,buflen,buffer1,nread);
		buflen=buflen+nread;
	}
    if(strcmp(buffer,"GET\n")==0){
		
		int try_number=0;
    	int input_num=0;
    	initibuf(buffer,32);
		while(buffer[0]!='\n'){
			initibuf(buffer,32);
			nread=read(a->fd,buffer,1);
			if(buffer[0]=='\n'){
				break;
			}
			input_num=input_num*10+buffer[0]-'0';
		}
		
		initibuf(buffer,32);
		
		
		nread = read(a->fd,buffer,input_num);
		buflen = nread;
		int num;
		for(num=0;buffer[num]!='\n';num++){
			
		}
		if(num+1==nread&&nread<input_num){
			printf("Bead length.\nClosing connection.\n");
				fclose(fout);
				free(value);
				free(a);
    			free(buffer);
				free(buffer1);
				return 0;
		}
		while(buflen<input_num){
			try_number++;
			nread=read(a->fd,buffer1,input_num-buflen);
		
			buffer=meltstring(buffer,buflen,buffer1,nread);
			buflen=buflen+nread;
			if(try_number==20){
				fclose(fout);
				free(value);
				free(a);
    			free(buffer);
				free(buffer1);
				return 0;
			}
		}
		if(buffer[input_num-1]!='\n'){
				printf("Less length.\nClosing connection.\n");
			fclose(fout);
				free(value);
				free(a);
    			free(buffer);
				free(buffer1);
				return 0;
		}
        //printf("[%s: %s] %c |%s| |%s|\n", host, port, 'G', buffer, value);
		if(get(a->list, buffer, (char**)&value)!=0) {
			fprintf(fout,"KNF\n");
			fflush(fout);
		}
		else{
			fprintf(fout, "OKG\n%ld\n%s\n", strlen(value)+1, value);
            fflush(fout);
		}
    }
    else if(strcmp(buffer,"SET\n")==0){
    	int try_number=0;
    	char input_key[32];
    	initibuf(input_key,32);
    	char input_value[32];
    	initibuf(input_value,32);

    	int input_num=0;
    	initibuf(buffer,32);
    		while(buffer[0]!='\n'){
			initibuf(buffer,32);
			nread=read(a->fd,buffer,1);
			
			if(buffer[0]=='\n'){
				break;
			}
			input_num=input_num*10+buffer[0]-'0';
		}
		initibuf(buffer,32);
		
		nread = read(a->fd,buffer,input_num);
		buflen = nread;
		int num;
		int nn=0;
		for(num=0;buffer[num]!='\n'||nn!=1;num++){
			if(buffer[num]=='\n')
			nn++;
		}
		
		if(num+1==nread&&nread<input_num){
			printf("Bad length.\nClosing connection.\n");
			;
			fclose(fout);
				free(value);
				free(a);
    			free(buffer);
				free(buffer1);
				return 0;
				
				return 0;
		}
		while(buflen<input_num){
			try_number++;
			nread=read(a->fd,buffer1,input_num-buflen);
		
			buffer=meltstring(buffer,buflen,buffer1,nread);
			buflen=buflen+nread;
			
		}
			if(buffer[input_num-1]!='\n'){
				printf("Bad length.\nClosing connection.\n");
			fclose(fout);
				
				return 0;
		}
		int order=0;
		while(buffer[order]!='\n'){
			input_key[order]=buffer[order];
			order++;
		}
		input_key[order]='\n';
		order++;
		int seoder=order;
		while(buffer[order]!='\n'){
			input_value[order-seoder]=buffer[order];
			order++;
		}
		input_value[order]='\n';
	
        //printf("[%s: %s] %c |%s| |%s|\n", host, port, 'S', input_key, input_value);
		set(a->list,input_key,input_value);
		fprintf(fout, "OKS\n");
    	fflush(fout);
    }
    else if(strcmp(buffer,"DEL\n")==0){
    
		int try_number=0;
    	int input_num=0;
    	initibuf(buffer,32);
		while(buffer[0]!='\n'){
			initibuf(buffer,32);
			nread=read(a->fd,buffer,1);
			if(buffer[0]=='\n'){
				break;
			}
			input_num=input_num*10+buffer[0]-'0';
		}
		initibuf(buffer,32);
		
		nread = read(a->fd,buffer,input_num);
		buflen = nread;
		int num;
		for(num=0;buffer[num]!='\n';num++){
			
		}

		if(num+1==nread&&nread<input_num){
			printf("Bad length.\nClosing connection.\n");
			fclose(fout);
				free(value);
				free(a);
    			free(buffer);
				free(buffer1);
				return 0;
		}
		while(buflen<input_num){
			try_number++;
			nread=read(a->fd,buffer1,input_num-buflen);
		
			buffer=meltstring(buffer,buflen,buffer1,nread);
			buflen=buflen+nread;
			if(try_number==20){
				fclose(fout);
				free(value);
				free(arg);
				return 0;
			}
		}
			if(buffer[input_num-1]!='\n'){
				printf("Bad length.\nClosing connection.\n");
			fclose(fout);
				free(value);
				free(a);
    			free(buffer);
				free(buffer1);
				return 0;
		}
        //printf("[%s: %s] %c |%s| |%s|\n", host, port, 'D', buffer, value);
		if(del(a->list, buffer, (char**)&value)!=0) {
                fprintf(fout, "KNF\n");
                fflush(fout);
            } else {
                fprintf(fout, "OKD\n%ld\n%s\n", strlen(value)+1, value);
                fflush(fout);
            }
    }
    else{
    		fprintf(fout, "ERR\nBAD\n");
            fflush(fout);
            printf("Bad format.\nClosing connection.\n");
            fclose(fout);
				free(value);
				free(a);
    			free(buffer);
				free(buffer1);
				return 0;
            return NULL;
    }
    
    printf("Waiting for input...\n");
    initibuf(buffer,32);
	initibuf(buffer1,32);
	free(value);
	}
    //n_print(a->list->head);

    fclose(fout);
    
    free(a);
    free(buffer);
	free(buffer1);
    printf("Closing connection.\n");
    return NULL;
}

int main(int argc, char* argv[argc+1]) {

    struct addrinfo hints, *info_list, *curr;
    int sfd, err;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    err = getaddrinfo(NULL, argv[1], &hints, &info_list); //check for error
    if(err!=0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(err));
        return EXIT_FAILURE;
    }

    for(curr = info_list; curr; curr = curr->ai_next) {

        sfd = socket(curr->ai_family, curr->ai_socktype, curr->ai_protocol);
        if(sfd<0) {
            continue;
        }
        if((bind(sfd, curr->ai_addr, curr->ai_addrlen)==0) && listen(sfd, BACKLOG)==0) {
            break;
        }
        close(sfd);
    }
    if(!curr) {
        fprintf(stderr, "Could not bind\n");
        return EXIT_FAILURE; 
    }

    freeaddrinfo(info_list);

    struct sigaction act;
    act.sa_handler = handler;
    act.sa_flags = 0;
    sigemptyset(&act.sa_mask);
    sigaction(SIGINT, &act, NULL);

    sigset_t mask;

    sigemptyset(&mask);
    sigaddset(&mask, SIGINT);

    struct args* A;
    pthread_t tid;
    LL* L = malloc(sizeof(LL));
    if(!L) {FAIL}
    l_init(L);

    while(running) {
        //arg for thread
        A = malloc(sizeof(struct args));
        if(!A) {FAIL}
        A->addr_len = sizeof(struct sockaddr_storage);
        //make space to store address
        //put in accept to get actual size
        
        A->fd = accept(sfd, (struct sockaddr *) &A->addr, &A->addr_len);
        //accept gig, will return the actual fd for communication
        //check fd from accept for error
        if(A->fd==-1) {
            perror("accept");
            continue;
        }

        err = pthread_sigmask(SIG_BLOCK, &mask, NULL);
        if(err!=0) {
            fprintf(stderr, "sigmask: %s\n", strerror(err));
            abort();
        } 
        //check error

        A->list = L;
        printf("Connection requested\n"); //???
        err = pthread_create(&tid, NULL, key, A);
        //check error from pthread create
        if(err!=0) {
            fprintf(stderr, "Unable to create thread: %d\n", err);
            free(A);
            continue;
        }

        pthread_detach(tid);
        //then detach the thread (wait for next connection req ig)

        err = pthread_sigmask(SIG_UNBLOCK, &mask, NULL);
        if(err!=0) {
            fprintf(stderr, "sigmask: %s\n", strerror(err));
            abort();
        }
        //check error
    }
    if(A) free(A);
    //_print(L->head);
    n_destroy(L->head);
    free(L);

    printf("No longer listening.\n");
    err = pthread_detach(pthread_self());
    if(err!=0) {
        fprintf(stderr, "pthread_detach: %s\n", strerror(err));
        abort();
    }
    pthread_exit(NULL);
    return EXIT_SUCCESS;
}
